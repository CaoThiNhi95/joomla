# Changelog

	1.0.1
	^ Warp Framework 7.3.13
	^ Uikit 2.23
	+ New feature Text columns
	+ Added article meta information options (Joomla)
    ^ Updated language files
    ^ J2store 3.2.1 http://j2store.org/component/ars/?view=release&id=93

	1.0.0
	+ Initial Release



	* -> Security Fix
	# -> Bug Fix
	$ -> Language fix or change
	+ -> Addition
	^ -> Change
	- -> Removed
	! -> Note
