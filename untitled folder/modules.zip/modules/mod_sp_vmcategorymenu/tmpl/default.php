<?php

    /**
    * @package SP VirtueMart Category Menu
    * @author JoomShaper http://www.joomshaper.com
    * @copyright Copyright (c) 2010 - 2013 JoomShaper
    * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
    */ 

?>
<div class="sp-vmmenu <?php echo $moduleclass_sfx; ?>" id="sp-vmmenu-<?php echo $module_id ?>">
    <ul>
        <?php echo $tree ?>
    </ul>
</div>

