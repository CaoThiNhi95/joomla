<?php
defined('_JEXEC') or die('Restricted access');

/**
 * 
 * XML to Array Exception
 *
 */
class XmlToArrayException extends Exception {}
?>