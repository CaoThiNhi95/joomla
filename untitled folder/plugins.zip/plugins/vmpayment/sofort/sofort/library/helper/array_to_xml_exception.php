<?php
defined('_JEXEC') or die('Restricted access');

/**
 * @author SOFORT AG (integration@sofort.com)
 * @link http://www.sofort.com/
 * 
 * Copyright (c) 2012 SOFORT AG
 *
 * Released under the GNU General Public License (Version 2)
 * [http://www.gnu.org/licenses/gpl-2.0.html]
 */

/**
 * 
 * Array To XML Exception
 *
 */
class ArrayToXmlException extends Exception {}
?>