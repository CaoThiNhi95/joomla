// Load when document finished loading
jQuery(function () {
    klarna.invoiceReady();
});

