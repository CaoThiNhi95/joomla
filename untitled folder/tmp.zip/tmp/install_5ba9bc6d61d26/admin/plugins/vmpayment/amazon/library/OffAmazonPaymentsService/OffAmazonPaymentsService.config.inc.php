<?php
$merchantId='';
$accessKey='';
$secretKey='';

/********************************************************************
 * Service endpoints for OffAmazonPaymentsService
 *
 * Swap between live and sandbox using the urls defined below
 *******************************************************************/
$region=''; // DE, UK or US
$environment=''; // SANDBOX or LIVE
$applicationName='';
$applicationVersion='';
//$caBundleFile='/etc/conf/certs/caCertFile.crt'; // Uncomment to enable caCertFile for unix
//$caBundleFile='C:\certs\caCertFile.crt';  // Uncomment to enable caCertFile for windows
?>